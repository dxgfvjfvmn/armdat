<?php

if (!defined('e107_INIT')) { exit; }

$TRACKBACK = "
<div class='fcaption'>{TITLE}</div>
{EXCERPT}<br />From: {BLOGNAME}<br /><br />
";

$TRACKBACK_RENDER_METHOD = TRUE;			/* TRUE=tablerender, FALSE=echo */

