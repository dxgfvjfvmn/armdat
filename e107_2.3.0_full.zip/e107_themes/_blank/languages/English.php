<?php
define("EMESSLAN_TITLE_INFO", "System Information");
//define("EMESSLAN_TITLE_ERROR", "Error");//new > LAN_ERROR
define("EMESSLAN_TITLE_SUCCESS", "Success");
define("EMESSLAN_TITLE_WARNING", "Warning");
define("EMESSLAN_TITLE_DEBUG", "System Debug");

define("LAN_THEME_1", "Comments are turned off for this item");
define("LAN_THEME_2", "Read/Post Comment: ");
define("LAN_THEME_3", "Read the rest...");
define("LAN_THEME_4", "Trackbacks: ");
define("LAN_THEME_5", "Posted by ");
define("LAN_THEME_6", "on ");
?>