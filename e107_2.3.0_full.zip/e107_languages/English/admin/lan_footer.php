<?php
/*
 * Copyright (C) 2008-2013 e107 Inc (e107.org), Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
 *
 * Admin Language File
 *
*/

define("FOOTLAN_1", "Site");
define("FOOTLAN_2", "Head Admin");
define("FOOTLAN_3", "Version");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Admin Theme");
define("FOOTLAN_6", "by");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Install date");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "host");
define("FOOTLAN_11", "PHP Version");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Site Info");
define("FOOTLAN_14", "Show Docs");
define("FOOTLAN_15", "Documentation");
define("FOOTLAN_16", "Database");
define("FOOTLAN_17", "Charset");
define("FOOTLAN_18", "Site Theme");
define("FOOTLAN_19", "Server Time");
define("FOOTLAN_20", "Security level");
