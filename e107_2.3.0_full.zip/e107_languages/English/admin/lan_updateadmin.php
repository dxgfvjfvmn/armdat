<?php
/*
 * Copyright e107 Inc e107.org, Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
 * $Id$
 *
 * Admin Language File
 * 
*/

define("UDALAN_1", "Error - please re-submit.");
define("UDALAN_2", "Admin Settings updated");
define("UDALAN_3", "Settings updated for");
define("UDALAN_4", "Name");
//define("UDALAN_5", "Password");//LAN_PASSWORD
define("UDALAN_6", "Re-type password");
define("UDALAN_7", "Change password");
define("UDALAN_8", "Password updated for");

